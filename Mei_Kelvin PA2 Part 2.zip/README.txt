Kelvin Mei
I attest that all submitted work is mine and I have not shared my code with any student nor gotten code from any student.

Implementation: I first created the constructors for basicClient and sharedClient with the apporpriate arguments so the Factory can call them and then overrode the toString method for both classes. 
In that method, I replaced the word CLIENT with SHARED/BASIC depending on the class and then have the method call super.getIndustry() and super.getName()
Next, I uncommented the lines generating clients and servers from the factory and commented the exceptions.
Lastly, I implemented synchronized methods in BasicServer. Using an array list and two synchronized methods, this server keeps track of the current clients and who can enter. 
Since the methods are synchronized, Threads cannot call the method if another Thread is currently processing the method. This prevents race conditions.

Part 2 Implementation:
I used locks and conditions to do the 2nd part. I locked the connectInner and disconnectInner methods for MasterServer and then used a condition to have the client wait until it is at the front of the queue. Each basic server has its own instance of condition in its own map to be efficient. Once it's at the front, it will connect and leave the queue. If it cannot connect, it will continue waiting until connection is possible. For disconnect, I had it disconnect the client and then signalAll the threads waiting on the condition. This allows the other clients to go check the while loop condition on whether or not they are in front of the queue and wait again if necessary.