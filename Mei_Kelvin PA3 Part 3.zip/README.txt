Kelvin Mei
PA3

Bitwise Implementation:
	isset --> using bitmasks and bitwise and operator to check
	set --> using bitmasks and bitwise or operator to set
	clear --> using bitmasks and bitwise or followed by xor to clear
	toString --> iterating through the byte using each bitmasks index and adding 1 if the bitwise and operator returns a non-zero, 0 otherwise.
	Byte[] variants require searching for the byte at the index bytes.length - 1 - i/8 and then calling the regular isset/set/clear.

Indirection Implementation
Split single/double/triple indirection into 3 blocks of code
If blockNum is > 9,
less than 10 + IndirectBlock.count will be Single Indirection.
less than 10 + IndirectBlock.count + IndirectBlock.count^2 will be Double Indirection
less than 10 + IndirectBlock.count + IndirectBlock.count^2 + IndirectBlock.count^3 will be Triple Indirection

For each of the indirections, I processed each one by layers, starting from inode to IndirectBlocks and then to DirectBlocks.
If a hole exists, it returns a hole if it's in read mode. If it's in write mode, it fills up the hole and subsequent IndirectBlocks based on the freeMap (null if freeMap.find() generates 0) and then returns the DirectBlock at the end.
If a hole doesn't exist, it means the IndirectBlock is already there and you can just read it in. After reading it in, if it contains pointers to DirectBlocks then you can return the DirectBlock after finding space for it on the freeMap. Otherwise, repeat the steps for checking holes above until you get to that layer. 
Note that everytime an IndirectBlock is changed it has to be written back to the disk and freeMap.save() has to be called after freeMap.find().

Double and Triple Indirection is just Single Indirection with more layers and more hole checking.

No known bugs as of now.