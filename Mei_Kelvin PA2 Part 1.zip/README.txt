Kelvin Mei
I attest that all submitted work is mine and I have not shared my code with any student nor gotten code from any student.

Implementation: I first created the constructors for basicClient and sharedClient with the apporpriate arguments so the Factory can call them and then overrode the toString method for both classes. 
In that method, I replaced the word CLIENT with SHARED/BASIC depending on the class and then have the method call super.getIndustry() and super.getName()
Next, I uncommented the lines generating clients and servers from the factory and commented the exceptions.
Lastly, I implemented synchronized methods in BasicServer. Using an array list and two synchronized methods, this server keeps track of the current clients and who can enter. 
Since the methods are synchronized, Threads cannot call the method if another Thread is currently processing the method. This prevents race conditions.

Possible Issues: Since Part 2 is not due, running the SimulationTest will have 1 pass and 1 error. 
